#!/usr/bin/env python3
from ..first_game import is_even_game


def greet():
    print("Welcome to the Brain Games!")


def main():
    greet()
    is_even_game()


if __name__ == '__main__':
    main()
